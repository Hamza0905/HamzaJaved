.model small
.stack 100h

.data
    savedPass db '112233$'
    inputPass db 5 dup('$')

    msg1 db 'Enter Password: $'
    msg2 db 0ah,0dh,'Access Granted$'
    msg3 db 0ah,0dh,'Access Denied$'

.code
main proc
    mov ax, @data
    mov ds, ax

    lea dx, msg1
    mov ah, 9
    int 21h

     lea dx, inputPass

input_loop:
    mov ah, 1
    int 21h

    cmp al, 13
    je compare_start

    mov [si], al
    inc si
    jmp input_loop

compare_start:
    lea dx, savedPass
    lea dx, inputPass

compare_loop:
    mov al, [si]
    mov bl, [di]

    cmp al, '$'
    je correct

    cmp al, bl
    jne wrong

    inc si
    inc di
    jmp compare_loop

correct:
    lea dx, msg2
    mov ah, 9
    int 21h
    jmp exit

wrong:
    lea dx, msg3
    mov ah, 9
    int 21h

exit:
    mov ah, 4ch
    int 21h

main endp
end main