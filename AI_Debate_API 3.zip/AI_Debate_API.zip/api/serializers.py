from rest_framework import serializers
from .models import Debate

class DebateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Debate
        fields = ['id', 'argument', 'counter_argument', 'created_at']
        read_only_fields = ['id', 'counter_argument', 'created_at']