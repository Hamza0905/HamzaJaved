from django.urls import path
from .views import home, DebateAPIView, DebateDetailAPIView

urlpatterns = [
    path('', home, name='home'),

    path('debate/', DebateAPIView.as_view(),
         name='debate-list-create'),

    path('debate/<int:pk>/',
         DebateDetailAPIView.as_view(),
         name='debate-detail'),
]