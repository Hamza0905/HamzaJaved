from django.contrib import admin
from .models import Debate

@admin.register(Debate)
class DebateAdmin(admin.ModelAdmin):
    list_display = ['id', 'argument', 'created_at']
    search_fields = ['argument']
