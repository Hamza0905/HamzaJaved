from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from drf_yasg.utils import swagger_auto_schema

from .models import Debate
from .serializers import DebateSerializer


def home(request):
    return render(request, 'home.html')


class DebateAPIView(APIView):

    def get(self, request):
        debates = Debate.objects.all().order_by('-created_at')
        serializer = DebateSerializer(debates, many=True)
        return Response(serializer.data)

    @swagger_auto_schema(request_body=DebateSerializer)
    def post(self, request):
        argument = request.data.get("argument")

        if not argument:
            return Response(
                {"error": "Argument is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        counter_argument = (
            f"Although '{argument}' has some advantages, opponents argue that "
            f"there are also drawbacks, limitations, and different perspectives "
            f"that should be considered before accepting it completely."
        )

        debate = Debate.objects.create(
            argument=argument,
            counter_argument=counter_argument
        )

        serializer = DebateSerializer(debate)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class DebateDetailAPIView(APIView):

    def get_object(self, pk):
        try:
            return Debate.objects.get(id=pk)
        except Debate.DoesNotExist:
            return None

    def get(self, request, pk):
        debate = self.get_object(pk)
        if debate is None:
            return Response({"error": "Debate not found"}, status=404)

        serializer = DebateSerializer(debate)
        return Response(serializer.data)

    @swagger_auto_schema(request_body=DebateSerializer)
    def put(self, request, pk):
        debate = self.get_object(pk)
        if debate is None:
            return Response({"error": "Debate not found"}, status=404)

        argument = request.data.get("argument")
        if not argument:
            return Response({"error": "Argument is required"}, status=400)

        debate.argument = argument
        debate.counter_argument = (
            f"Although '{argument}' may seem valid, critics argue that "
            f"it has weaknesses and can be challenged with logical counterpoints."
        )
        debate.save()

        serializer = DebateSerializer(debate)
        return Response(serializer.data)

    @swagger_auto_schema(request_body=DebateSerializer)
    def patch(self, request, pk):
        debate = self.get_object(pk)
        if debate is None:
            return Response({"error": "Debate not found"}, status=404)

        argument = request.data.get("argument", debate.argument)

        debate.argument = argument
        debate.counter_argument = (
            f"Although '{argument}' has a strong point, another perspective "
            f"shows that it may not be true in every situation."
        )
        debate.save()

        serializer = DebateSerializer(debate)
        return Response(serializer.data)

    def delete(self, request, pk):
        debate = self.get_object(pk)
        if debate is None:
            return Response({"error": "Debate not found"}, status=404)

        debate.delete()
        return Response({"message": "Debate deleted successfully"})