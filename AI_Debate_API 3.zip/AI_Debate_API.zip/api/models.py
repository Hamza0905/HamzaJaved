from django.db import models

class Debate(models.Model):
    argument = models.TextField()
    counter_argument = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.argument[:50]